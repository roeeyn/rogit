# Rogit
This is a little automation for lazy devs like me

## Installation
```bash
pip3 install rogit
```

## Usage
Inside your terminal, at the folder of your code, type
```bash
rogit
```
And it will prompt for the necessary info (mainly the commit message).

Made with 💙 from 🇲🇽